Terms Of Use
By downloading or using our font, you are read and accept to the Our Term and Use Agreement :This font is copyrighted and protected by the law. Usage of this font on any work without proper license is
deemed as illegal. You might get fined for at least USD 3000 for this act. Please do understand that we have our own system for tracking the usage of our works on internet.

- Free ONLY for PERSONAL USE ( NON COMMERCIAL USE )

- BUY THIS FONT : https://creativemarket.com/Lilmo/6503806-Kinsans-Sans-Serif-Font

-You may not Capture screen shots, record video, record audio and copy text from products to use as press material, without permission from our company.

- For Corporate or Commercial use you have to purchase Corporate and commercial license, please
contact us at : ryanrivaldovierra@gmail.com

- Any donation are acceptable and very appreciated. Here is Our Paypal account for donation : https://www.paypal.com/paypalme/ryanrivaldovierra

Follow our social media for update :
Twitter : https://twitter.com/Ryaanrivaldovi1
Instagram : https://www.instagram.com/ryanrivaldovierra/
Facebook : https://www.facebook.com/ryan.vierra.9/